﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainMenuForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnStartGame = New Button()
        btnExit = New Button()
        Panel1 = New Panel()
        btnCredit = New Button()
        Label1 = New Label()
        Panel2 = New Panel()
        Label2 = New Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnStartGame
        ' 
        btnStartGame.BackColor = SystemColors.ButtonHighlight
        btnStartGame.FlatStyle = FlatStyle.Flat
        btnStartGame.Font = New Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnStartGame.ForeColor = Color.Navy
        btnStartGame.Location = New Point(83, 282)
        btnStartGame.Name = "btnStartGame"
        btnStartGame.Size = New Size(141, 49)
        btnStartGame.TabIndex = 0
        btnStartGame.Text = "Play Game"
        btnStartGame.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = SystemColors.ButtonHighlight
        btnExit.FlatStyle = FlatStyle.Flat
        btnExit.Font = New Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.ForeColor = Color.Navy
        btnExit.Location = New Point(83, 433)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(141, 49)
        btnExit.TabIndex = 1
        btnExit.Text = "ExitGame"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Transparent
        Panel1.BackgroundImageLayout = ImageLayout.Stretch
        Panel1.Controls.Add(btnCredit)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(btnStartGame)
        Panel1.Controls.Add(btnExit)
        Panel1.Location = New Point(183, 33)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(311, 516)
        Panel1.TabIndex = 2
        ' 
        ' btnCredit
        ' 
        btnCredit.BackColor = SystemColors.ButtonHighlight
        btnCredit.FlatStyle = FlatStyle.Flat
        btnCredit.Font = New Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCredit.ForeColor = Color.Navy
        btnCredit.Location = New Point(83, 360)
        btnCredit.Name = "btnCredit"
        btnCredit.Size = New Size(141, 49)
        btnCredit.TabIndex = 3
        btnCredit.Text = "Credits"
        btnCredit.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Navy
        Label1.Location = New Point(83, 213)
        Label1.Name = "Label1"
        Label1.Size = New Size(141, 49)
        Label1.TabIndex = 2
        Label1.Text = "Main Menu"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.Transparent
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(45, 33)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(561, 210)
        Panel2.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Times New Roman", 72F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(3, 23)
        Label2.Name = "Label2"
        Label2.Size = New Size(597, 163)
        Label2.TabIndex = 0
        Label2.Text = "TETRIS"
        ' 
        ' MainMenuForm
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Control
        BackgroundImage = My.Resources.Resources.download__4_
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(678, 603)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.FixedSingle
        MaximizeBox = False
        MinimizeBox = False
        Name = "MainMenuForm"
        Text = "Form1"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnStartGame As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCredit As Button
    Friend WithEvents Label2 As Label

End Class
