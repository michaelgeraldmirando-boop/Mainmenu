﻿Friend Class PopupForm
    Public Sub New()
    End Sub

    Friend Sub Show()
        Throw New NotImplementedException()
    End Sub

    Friend Sub ShowDialog()
        Throw New NotImplementedException()
    End Sub
End Class
