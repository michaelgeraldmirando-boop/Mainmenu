﻿

Public Class MainMenuForm ' set startup as MainMenuForm in properties mmhmhmhmhmhmh
    Inherits Form

    Private WithEvents CreditsButton As New Button()
    Private creditsText As String = "This application was created by: Faizan Fayyaz, Karl Lopez, Val Marco, Gerald Mirando"
    Private Sub btnStartGame_Click(sender As Object, e As EventArgs) Handles btnStartGame.Click
        Me.Hide()
        Using tetrisGame As New TetrisForm() ' name the TetrisForm as the form name ex. MainMenuForm()
            tetrisGame.ShowDialog()
        End Using
        Me.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCredit_Click(sender As Object, e As EventArgs) Handles btnCredit.Click
        MessageBox.Show(creditsText, "Credits")
    End Sub
End Class
Module Program
    Sub Main()
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New MainMenuForm())
    End Sub
End Module
