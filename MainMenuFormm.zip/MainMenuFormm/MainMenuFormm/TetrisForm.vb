﻿Public Class TetrisForm
    Inherits Form

    Private Const GridRows As Integer = 20
    Private Const GridCols As Integer = 10
    Private gridPanel As Panel
    Private previewPanel As Panel
    Private timerLabel As Label
    Private gameTimer As Timer
    Private elapsedTime As Integer

    Public Sub New()
        Dim exitButton As New Button()
        exitButton.Text = "Exit"
        exitButton.Size = New Size(100, 40)
        exitButton.Location = New Point(300, 300)
        AddHandler exitButton.Click, AddressOf ExitButton_Click
        Me.Controls.Add(exitButton)
        Me.Text = "Tetris - .NET 8 Edition"
        Me.Size = New Size(500, 480)
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False



        gridPanel = New Panel()
        gridPanel.Location = New Point(30, 30)
        gridPanel.Size = New Size(240, 400)
        gridPanel.BorderStyle = BorderStyle.FixedSingle
        gridPanel.BackColor = Color.Black
        AddHandler gridPanel.Paint, AddressOf DrawTetrisGrid
        Me.Controls.Add(gridPanel)


        previewPanel = New Panel()
        previewPanel.Location = New Point(300, 70)
        previewPanel.Size = New Size(100, 100)
        previewPanel.BorderStyle = BorderStyle.FixedSingle
        previewPanel.BackColor = Color.White
        AddHandler previewPanel.Paint, AddressOf DrawNextBlockPreview
        Me.Controls.Add(previewPanel)


        timerLabel = New Label()
        timerLabel.Location = New Point(300, 200)
        timerLabel.Size = New Size(100, 40)
        timerLabel.Font = New Font("Segoe UI", 18, FontStyle.Bold)
        timerLabel.TextAlign = ContentAlignment.MiddleCenter
        timerLabel.Text = "00:00"
        Me.Controls.Add(timerLabel)


        gameTimer = New Timer()
        gameTimer.Interval = 1000
        AddHandler gameTimer.Tick, AddressOf OnGameTick
        gameTimer.Start()
    End Sub

    Private Sub OnGameTick(sender As Object, e As EventArgs)
        elapsedTime += 1
        Dim mins As Integer = elapsedTime \ 60
        Dim secs As Integer = elapsedTime Mod 60
        timerLabel.Text = $"{mins:D2}:{secs:D2}"
    End Sub

    Private Sub DrawTetrisGrid(sender As Object, e As PaintEventArgs)
        Dim cellSize As Integer = Math.Min(gridPanel.Width \ GridCols, gridPanel.Height \ GridRows)
        Dim g As Graphics = e.Graphics
        Dim p As New Pen(Color.Gray)
        For row = 0 To GridRows - 1
            For col = 0 To GridCols - 1
                g.DrawRectangle(p, col * cellSize, row * cellSize, cellSize, cellSize)
            Next
        Next
        p.Dispose()
    End Sub

    Private Sub DrawNextBlockPreview(sender As Object, e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        Dim blockBrush As New SolidBrush(Color.Blue)
        g.FillRectangle(blockBrush, 30, 40, 40, 10)
        g.FillRectangle(blockBrush, 45, 30, 10, 20)
        blockBrush.Dispose()
    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub
End Class
