﻿Public Class Form1

    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        ' Create an instance of the popup form
        Dim popup As New MainMenuForm()

        ' Display the popup form as a modal dialog
        MainMenuForm.ShowDialog()

        ' Optional: Dispose of the popup form after it is closed
        MainMenuForm.Dispose()
    End Sub
End Class